# ABYSS — Pitch Deck (Starter)

1. Cover: ABYSS — by MIDAS. Logo.
2. Problem: custody vs convenience vs privacy. Market size.
3. Solution: Hybrid cold + vault, Ghost, Decoy, Inheritance.
4. Product: Demo screenshots, modes (NORMAL/SECURE/ANON/GHOST).
5. Technology: Rust core (open), MPC vault (closed), USB cold.
6. Business model: Vault fees, Pro subs, White-label.
7. Roadmap: 0–9 months (core, vault, launch).
8. Team & ask: hires + raise (seed).
9. Security: audits, bug-bounty, insurance.
10. Contact: MIDAS — founder@abyss.example (placeholder)
