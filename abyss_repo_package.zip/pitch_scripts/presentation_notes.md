# Pitch notes (talking points)

Slide 1: Hook — "Where does real wealth go when it's removed from the world? ABYSS."
Slide 2: Quick market numbers + trust problem.
Slide 3: Show hybrid demo: cold + vault.
Slide 4: Security deep-dive: open core, MPC, audits.
Slide 5: Monetization and partnerships.
Slide 6: Team & ask.
