Legal notes (high level)
- Decide jurisdiction for vault operations
- AML/KYC options for custodial flows (configurable)
- Prepare privacy policy & terms
- Engage security & compliance counsel before public release
